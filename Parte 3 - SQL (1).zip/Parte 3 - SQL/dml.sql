INSERT INTO Unidade_Logistica (CNPJ, local_CEP) VALUES 
('11.111.111/0001-11', '01001-000'),
('22.222.222/0001-22', '20040-000'),
('33.333.333/0001-33', '30110-000');

INSERT INTO Funcionario (id_func, CPF_func, nome, salario, id_unidade_logistica) VALUES 
(1, '111.111.111-11', 'Carlos Silva', 3200.00, '11.111.111/0001-11'),
(2, '222.222.222-22', 'Ana Souza', 3500.00, '11.111.111/0001-11'),
(3, '333.333.333-33', 'Roberto Santos', 3100.00, '22.222.222/0001-22'),
(4, '444.444.444-44', 'Juliana Lima', 4200.00, '33.333.333/0001-33');

INSERT INTO Veiculo (Numero_placa, Capacidade_carga, Tipo_veiculo, id_func) VALUES 
('ABC-1234', 1500.00, 'Caminhão Baú', 1),
('XYZ-5678', 800.00, 'Furgão', 2),
('KJM-9012', 2000.00, 'Caminhão', 3),
('DEF-5678', 500.00, 'Van', 4);

INSERT INTO Rota (ID_rota, origem_rota, destino_rota) VALUES 
(101, 'São Paulo - SP', 'Rio de Janeiro - RJ'),
(102, 'Rio de Janeiro - RJ', 'Belo Horizonte - MG'),
(103, 'São Paulo - SP', 'Campinas - SP');

INSERT INTO Veiculo_rota (ID_veiculo_rota, Data_hora_inicio, Numero_placa, ID_rota) VALUES 
(1, '2026-05-18 08:00:00', 'ABC-1234', 101),
(2, '2026-05-18 09:30:00', 'XYZ-5678', 103),
(3, '2026-05-19 06:00:00', 'KJM-9012', 102),
(4, '2026-05-19 14:00:00', 'ABC-1234', 101);

INSERT INTO Clientes (CPF_CNPJ, nome_cliente, endereco_CEP, endereco_numero, endereco_rua, telefone) VALUES 
('123.456.789-00', 'Empresa Alfa Ltda', '01311-000', 1000, 'Av. Paulista', '11999991111'),
('987.654.321-11', 'Marcos Oliveira', '22020-001', 45, 'Copacabana', '21988882222'),
('456.789.123-22', 'Fernanda Costa', '31270-010', 120, 'Pampulha', '31977773333');

INSERT INTO Telefones_Clientes (num_telefone, CPF_CNPJ) VALUES 
('1133334444', '123.456.789-00'),
('2122223333', '987.654.321-11');

INSERT INTO Pedido (ID_pedido, preco_pedido, data_hora_pedido, CPF_CNPJ) VALUES 
(5001, 250.50, '2026-05-15 10:00:00', '123.456.789-00'),
(5002, 1200.00, '2026-05-16 11:30:00', '987.654.321-11'),
(5003, 85.00, '2026-05-17 15:20:00', '123.456.789-00'),
(5004, 430.00, '2026-05-17 16:00:00', '456.789.123-22');

INSERT INTO Pacotes (Codigo_rastreio, peso_pacote, ID_pedido) VALUES 
('BR123456789BR', 12.500, 5001),
('BR987654321BR', 45.200, 5002),
('BR555444333BR', 1.200, 5003),
('BR111222333BR', 8.750, 5004),
('BR999888777BR', 3.400, 5002);

INSERT INTO Status_Pacote (Codigo_rastreio, status_atual, data_hora) VALUES 
('BR123456789BR', 'Postado', '2026-05-15 14:00:00'),
('BR123456789BR', 'Em Trânsito', '2026-05-16 08:00:00'),
('BR987654321BR', 'Postado', '2026-05-16 13:00:00'),
('BR555444333BR', 'Entregue', '2026-05-18 17:00:00'),
('BR111222333BR', 'Postado', '2026-05-17 18:00:00');

INSERT INTO Unidade_Pacotes (ID_unidade_pacote, Codigo_rastreio, CNPJ) VALUES 
(1, 'BR123456789BR', '11.111.111/0001-11'),
(2, 'BR987654321BR', '22.222.222/0001-22'),
(3, 'BR555444333BR', '11.111.111/0001-11'),
(4, 'BR111222333BR', '33.333.333/0001-33');