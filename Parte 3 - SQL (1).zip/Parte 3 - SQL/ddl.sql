CREATE TABLE Clientes (
    CPF_CNPJ VARCHAR(18) PRIMARY KEY,
    nome_cliente VARCHAR(100) NOT NULL,
    endereco_CEP VARCHAR(15) NOT NULL,
    endereco_numero INT NOT NULL,
    endereco_rua VARCHAR(100) NOT NULL,
    telefone VARCHAR(20)
);

CREATE TABLE Telefones_Clientes (
    num_telefone VARCHAR(20),
    CPF_CNPJ VARCHAR(18),
    PRIMARY KEY (num_telefone, CPF_CNPJ),
    FOREIGN KEY (CPF_CNPJ) REFERENCES Clientes(CPF_CNPJ) ON DELETE CASCADE
);

CREATE TABLE Pedido (
    ID_pedido INT PRIMARY KEY,
    preco_pedido DECIMAL(10, 2) NOT NULL CHECK (preco_pedido >= 0),
    data_hora_pedido TIMESTAMP NOT NULL,
    CPF_CNPJ VARCHAR(18) NOT NULL,
    FOREIGN KEY (CPF_CNPJ) REFERENCES Clientes(CPF_CNPJ)
);

CREATE TABLE Pacotes (
    Codigo_rastreio VARCHAR(50) PRIMARY KEY,
    peso_pacote DECIMAL(6, 3) NOT NULL CHECK (peso_pacote > 0),
    ID_pedido INT NOT NULL,
    FOREIGN KEY (ID_pedido) REFERENCES Pedido(ID_pedido)
);

CREATE TABLE Status_Pacote (
    Codigo_rastreio VARCHAR(50),
    status_atual VARCHAR(50) NOT NULL,
    data_hora TIMESTAMP NOT NULL,
    PRIMARY KEY (Codigo_rastreio, status_atual, data_hora),
    FOREIGN KEY (Codigo_rastreio) REFERENCES Pacotes(Codigo_rastreio) ON DELETE CASCADE
);

CREATE TABLE Unidade_Logistica (
    CNPJ VARCHAR(18) PRIMARY KEY,
    local_CEP VARCHAR(15) NOT NULL
);

CREATE TABLE Unidade_Pacotes (
    ID_unidade_pacote INT PRIMARY KEY,
    Codigo_rastreio VARCHAR(50) NOT NULL,
    CNPJ VARCHAR(18) NOT NULL,
    FOREIGN KEY (Codigo_rastreio) REFERENCES Pacotes(Codigo_rastreio),
    FOREIGN KEY (CNPJ) REFERENCES Unidade_Logistica(CNPJ)
);

CREATE TABLE Rota (
    ID_rota INT PRIMARY KEY,
    origem_rota VARCHAR(100) NOT NULL,
    destino_rota VARCHAR(100) NOT NULL
);

CREATE TABLE Veiculo_rota (
    ID_veiculo_rota INT PRIMARY KEY,
    Data_hora_inicio DATETIME NOT NULL,
    Numero_placa VARCHAR(15) NOT NULL,
    ID_rota INT NOT NULL
);

CREATE TABLE Funcionario (
    id_func INT PRIMARY KEY,
    CPF_func VARCHAR(18) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    salario DECIMAL(10, 2) NOT NULL CHECK (salario > 0),
    id_unidade_logistica VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_unidade_logistica) REFERENCES Unidade_Logistica(CNPJ)
);

CREATE TABLE Veiculo (
    Numero_placa VARCHAR(15) PRIMARY KEY,
    Capacidade_carga DECIMAL(8, 2) NOT NULL CHECK (Capacidade_carga > 0),
    Tipo_veiculo VARCHAR(50) NOT NULL,
    id_func INT NOT NULL,
    FOREIGN KEY (id_func) REFERENCES Funcionario(id_func)
);

ALTER TABLE Veiculo_rota ADD CONSTRAINT fk_veiculo_placa FOREIGN KEY (Numero_placa) REFERENCES Veiculo(Numero_placa);
ALTER TABLE Veiculo_rota ADD CONSTRAINT fk_rota_id FOREIGN KEY (ID_rota) REFERENCES Rota(ID_rota);