-- Primeira consulta: Filtrar e ordenar dados de múltiplas relações
-- Descrição: Lista todos os pedidos efetuados por clientes individuais ou corporativos, 
--            incluindo o nome do cliente, o ID do pedido e o valor total cobrado.
--            Filtra apenas pedidos com valor superior a R$ 200,00 e ordena de forma decrescente pelo preço.
-- Relevância: Essencial para o setor financeiro e comercial identificar os clientes com maior 
--             ticket de compra recente e priorizar o atendimento logístico destes pedidos.

SELECT 
    C.nome_cliente, 
    P.ID_pedido, 
    P.preco_pedido, 
    P.data_hora_pedido
FROM 
    Pedido P
INNER JOIN 
    Clientes C ON P.CPF_CNPJ = C.CPF_CNPJ
WHERE 
    P.preco_pedido > 200.00
ORDER BY 
    P.preco_pedido DESC;


-- Segunda consulta: Sumarizar e analisar dados agregados
-- Descrição: Lista os funcionários e calcula a capacidade total de carga que cada um gerencia,
--            além de contar a quantidade de veículos atribuídos a ele. Junta 3 tabelas 
--            (Unidade_Logistica, Funcionario, Veiculo) e agrupa por funcionário e unidade.
-- Relevância: Permite à gerência de operações monitorar a distribuição de carga de trabalho e a 
--             responsabilidade patrimonial da frota entre os motoristas contratados em cada unidade.

SELECT 
    UL.local_CEP AS CEP_Unidade,
    F.nome AS Nome_Funcionario,
    COUNT(V.Numero_placa) AS Qtd_Veiculos_Alocados,
    SUM(V.Capacidade_carga) AS Capacidade_Total_KG
FROM 
    Funcionario F
INNER JOIN 
    Unidade_Logistica UL ON F.id_unidade_logistica = UL.CNPJ
INNER JOIN 
    Veiculo V ON V.id_func = F.id_func
GROUP BY 
    UL.local_CEP, F.nome
ORDER BY 
    Capacidade_Total_KG DESC;


-- Terceira consulta: Combinar agregação com filtragens complexas (Subconsultas e 4+ tabelas)
-- Descrição: Apresenta informações detalhadas do fluxo de pacotes pesados. Exibe o código de rastreio,
--            o peso do pacote, o nome do cliente destinatário, a cidade de origem da rota e a placa do veículo.
--            Realiza o INNER JOIN de 5 tabelas (Pacotes, Pedido, Clientes, Veiculo_rota, Rota)
--            e utiliza uma subconsulta correlacionada no WHERE para filtrar apenas pacotes cujo peso 
--            seja estritamente maior que a média de peso de todos os pacotes enviados daquele mesmo cliente.
-- Relevância: Crucial para o planeamento de frotas pesadas, permitindo isolar anomalias de carga de 
--             clientes recorrentes que possam exigir veículos de maior porte nas rotas padrão.

SELECT 
    PAC.Codigo_rastreio,
    PAC.peso_pacote,
    CLI.nome_cliente,
    R.origem_rota,
    VR.Numero_placa
FROM 
    Pacotes PAC
INNER JOIN 
    Pedido PED ON PAC.ID_pedido = PED.ID_pedido
INNER JOIN 
    Clientes CLI ON PED.CPF_CNPJ = CLI.CPF_CNPJ
INNER JOIN 
    Veiculo_rota VR ON VR.ID_rota = 101
INNER JOIN 
    Rota R ON VR.ID_rota = R.ID_rota
WHERE 
    PAC.peso_pacote > (
        SELECT AVG(P_SUB.peso_pacote)
        FROM Pacotes P_SUB
        INNER JOIN Pedido PED_SUB ON P_SUB.ID_pedido = PED_SUB.ID_pedido
        WHERE PED_SUB.CPF_CNPJ = CLI.CPF_CNPJ
    );